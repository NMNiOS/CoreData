//
//  VIP+CoreDataClass.swift
//  HitList
//
//  Created by Karunakar Bandikatla on 14/07/17.
//  Copyright © 2017 Karunakar Bandikatla. All rights reserved.
//

import Foundation
import CoreData

@objc(VIP)
public class VIP: Person {

}
