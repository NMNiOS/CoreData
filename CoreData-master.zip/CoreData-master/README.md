# CoreData
Coredata Practice
